package Negocio;
import Modelagem.Aluno;

public class Vetor {
	
	 public Aluno[] alunos = new Aluno[3];
	 
	 	public void adcionarAluno(int posicao ,Aluno aluno) {
	 		alunos[posicao]=aluno;
	 	}
	 	public void adcionarNota(int posicao ,Aluno aluno) {
	 		alunos[posicao]=aluno;
	 	}
	 	public void adcionarMatricula(int posicao ,Aluno aluno) {
	 		alunos[posicao]=aluno;
	 	}
	 	public void adcionarIdade(int posicao ,Aluno aluno) {
	 		alunos[posicao]=aluno;
	 	}
}